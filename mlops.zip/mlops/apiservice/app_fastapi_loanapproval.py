from fastapi import FastAPI, HTTPException
from pydantic import BaseModel, Field
from typing import List, Optional
import pickle
import pandas as pd
import uvicorn

app = FastAPI(
    title="Loan Approval Prediction API",
    description="API for predicting loan approval using a Random Forest model",
    version="1.0.0"
)

# Define input data models
class LoanApplication(BaseModel):
    age: int = Field(..., ge=18, le=100, description="Age of the applicant")
    credit_score: int = Field(..., ge=300, le=850, description="Credit score of the applicant")
    income: int = Field(..., ge=0, description="Annual income of the applicant")
    loan_amount: int = Field(..., ge=0, description="Requested loan amount")

class PredictionResponse(BaseModel):
    prediction: str
    probability: float
    input_data: dict

# Load the model when the application starts
def load_model():
    with open('loan_approval_model.pkl', 'rb') as file:
        return pickle.load(file)

model = load_model()

@app.get("/health")
async def health_check():
    return {"status": "healthy"}

@app.post("/predict", response_model=PredictionResponse)
async def predict(application: LoanApplication):
    try:
        # Convert input to DataFrame
        input_data = pd.DataFrame([application.dict()])
        
        # Make prediction
        prediction = model.predict(input_data)[0]
        probability = model.predict_proba(input_data)[0][1]
        
        # Prepare response
        response = PredictionResponse(
            prediction='Approved' if prediction == 1 else 'Not Approved',
            probability=float(probability),
            input_data=application.dict()
        )
        
        return response
    
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.post("/batch_predict", response_model=List[PredictionResponse])
async def batch_predict(applications: List[LoanApplication]):
    try:
        # Convert input to DataFrame
        input_data = pd.DataFrame([app.dict() for app in applications])
        
        # Make predictions
        predictions = model.predict(input_data)
        probabilities = model.predict_proba(input_data)[:, 1]
        
        # Prepare response
        response = [
            PredictionResponse(
                prediction='Approved' if pred == 1 else 'Not Approved',
                probability=float(prob),
                input_data=app.dict()
            )
            for pred, prob, app in zip(predictions, probabilities, applications)
        ]
        
        return response
    
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

if __name__ == "__main__":
    uvicorn.run(app, host="0.0.0.0", port=8000)