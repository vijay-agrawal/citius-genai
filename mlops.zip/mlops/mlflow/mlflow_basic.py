#pip install mlflow

import mlflow.sklearn

model = joblib.load("random_forest_model.joblib")
mlflow.sklearn.save_model(model, "mlflow_model")

# Start MLFlow API Server
# mlflow models serve -m mlflow_model --port 5001

#Test the API
# curl -X POST "http://127.0.0.1:5001/invocations" -H "Content-Type: application/json" -d '{"dataframe_split": {"columns": ["feature1", "feature2"], "data": [[1, 2]]}}'

# Pros: Tracks experiments, deploys on cloud easily.
# Cons: Requires MLflow setup, larger dependencies.

