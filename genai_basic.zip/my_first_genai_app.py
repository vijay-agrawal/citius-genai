import os
from openai import AzureOpenAI
from dotenv import load_dotenv

load_dotenv()

# If running in google colab, uncomment following lines and set the appropriate values in the environment
# os.environ ["AZURE_OPENAI_ENDPOINT"] = ""
# os.environ ["AZURE_OPENAI_API_KEY"] = "" 
# os.environ ["AZURE_OPENAI_MODEL_DEPLOYMENT_NAME"] = "gpt-35-turbo"
# os.environ ["AZURE_OPENAI_MODEL_NAME"] = "gpt-35-turbo"
# os.environ ["AZURE_OPENAI_API_VERSION"] = "2024-02-01" 
azure_config = {
    "AZURE_OPENAI_ENDPOINT": os.getenv("AZURE_OPENAI_ENDPOINT"),
    "AZURE_OPENAI_MODEL_DEPLOYMENT_NAME": os.getenv("AZURE_OPENAI_MODEL_DEPLOYMENT_NAME"),
    "AZURE_OPENAI_MODEL_NAME": os.getenv("AZURE_OPENAI_MODEL_NAME"),
    "AZURE_OPENAI_API_KEY": os.getenv("AZURE_OPENAI_API_KEY"),
    "AZURE_OPENAI_API_VERSION": os.getenv("AZURE_OPENAI_API_VERSION")
    }

#print (azure_config)
prompt = 'who is the best cricketer in the world?'

client = AzureOpenAI(
    azure_endpoint=azure_config["AZURE_OPENAI_ENDPOINT"],
    api_key=azure_config["AZURE_OPENAI_API_KEY"],
    api_version=azure_config["AZURE_OPENAI_API_VERSION"]
)
model_name=azure_config["AZURE_OPENAI_MODEL_NAME"]

try:
    response = client.chat.completions.create(
    model=model_name,
    messages=[
        {"role": "system", "content": "You are a helpful assistant."},
        {"role": "user", "content": prompt}
    ] )
    #print (response)
    answer = response.choices[0].message.content.strip()
except Exception as e:
    print(e) # Log error and continue
    
print(prompt)
print(answer)
