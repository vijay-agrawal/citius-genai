## Save the Loan approval prediction model in pickle and joblib format

## Load the model and do prediction with sample data

## Explore difference between the 2 formats - file size, layout etc.
## Use chatgpt or other tools to find out the differrent formats and
## their pros and cons
##


