from flask import Flask, request, jsonify
import pickle
import pandas as pd
from waitress import serve

app = Flask(__name__)

# Load the model when the application starts
def load_model():
    with open('loan_approval_model.pkl', 'rb') as file:
        return pickle.load(file)

model = load_model()

@app.route('/health', methods=['GET'])
def health_check():
    return jsonify({'status': 'healthy'}), 200

@app.route('/predict', methods=['POST'])
def predict():
    try:
        # Get the input data from the request
        data = request.get_json()
        
        # Validate required fields
        required_fields = ['age', 'credit_score', 'income', 'loan_amount']
        for field in required_fields:
            if field not in data:
                return jsonify({'error': f'Missing required field: {field}'}), 400
        
        # Create DataFrame from input
        input_data = pd.DataFrame([data])
        
        # Make prediction
        prediction = model.predict(input_data)[0]
        probability = model.predict_proba(input_data)[0][1]
        
        # Prepare response
        response = {
            'prediction': 'Approved' if prediction == 1 else 'Not Approved',
            'probability': float(probability),
            'input_data': data
        }
        
        return jsonify(response), 200
    
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/batch_predict', methods=['POST'])
def batch_predict():
    try:
        # Get the input data from the request
        data = request.get_json()
        
        if not isinstance(data, list):
            return jsonify({'error': 'Input must be a list of loan applications'}), 400
        
        # Create DataFrame from input
        input_data = pd.DataFrame(data)
        
        # Validate required fields
        required_fields = ['age', 'credit_score', 'income', 'loan_amount']
        missing_fields = [field for field in required_fields if field not in input_data.columns]
        if missing_fields:
            return jsonify({'error': f'Missing required fields: {missing_fields}'}), 400
        
        # Make predictions
        predictions = model.predict(input_data)
        probabilities = model.predict_proba(input_data)[:, 1]
        
        # Prepare response
        response = [{
            'prediction': 'Approved' if pred == 1 else 'Not Approved',
            'probability': float(prob),
            'input_data': input_data.iloc[i].to_dict()
        } for i, (pred, prob) in enumerate(zip(predictions, probabilities))]
        
        return jsonify(response), 200
    
    except Exception as e:
        return jsonify({'error': str(e)}), 500

if __name__ == '__main__':
    # Use waitress for production-grade serving
    serve(app, host='0.0.0.0', port=5000)