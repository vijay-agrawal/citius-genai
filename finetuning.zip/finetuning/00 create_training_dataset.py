import pandas as pd

# Create a dataset of Ayurvedic remedies with instructions and responses
# To be used to fine tune a language model
data = [
    # 1) Cough
    {
        "instruction": "What is a simple Ayurvedic remedy for a cough?",
        "response": (
            "A common option is warm water mixed with a pinch of turmeric and ginger. "
            "Sipping it regularly may soothe throat irritation."
        )
    },
    {
        "instruction": "Which herbs are suggested in Ayurveda to relieve cough symptoms?",
        "response": (
            "Tulsi (holy basil), licorice root, and ginger are frequently used. They can help reduce mucus "
            "and calm the respiratory tract."
        )
    },

    # 2) Cold
    {
        "instruction": "How does Ayurveda suggest treating a common cold?",
        "response": (
            "Drink warm liquids, avoid cold foods, and rest. Simple concoctions with ginger, tulsi, or "
            "black pepper may ease congestion."
        )
    },
    {
        "instruction": "Which Ayurvedic spices help with nasal congestion from a cold?",
        "response": (
            "Ginger, pepper, and cinnamon can help open nasal passages. A light steam inhalation with "
            "eucalyptus oil is also beneficial."
        )
    },

    # 3) Stomach Ache
    {
        "instruction": "What is a quick Ayurvedic fix for a mild stomach ache?",
        "response": (
            "A small dose of hing (asafoetida) mixed in warm water can help reduce bloating and discomfort. "
            "Avoid heavy meals until you feel better."
        )
    },
    {
        "instruction": "Which simple home remedies does Ayurveda recommend for stomach pain?",
        "response": (
            "Sipping on fennel seed tea or chewing ajwain seeds may help. These spices support digestion "
            "and ease cramps."
        )
    },

    # 4) Indigestion
    {
        "instruction": "How can I address indigestion using Ayurveda?",
        "response": (
            "Focus on light, warm meals and sip hot water throughout the day. Herbs like cumin and coriander "
            "improve digestion."
        )
    },
    {
        "instruction": "Which Ayurvedic practices prevent recurring indigestion?",
        "response": (
            "Eating meals on a regular schedule, avoiding overeating, and including ginger or cumin in cooking "
            "promote healthy digestion."
        )
    },

    # 5) Constipation
    {
        "instruction": "What is a simple Ayurvedic approach for relieving constipation?",
        "response": (
            "Drinking warm water first thing in the morning and adding flaxseeds or psyllium husk to your diet "
            "can help regulate bowel movements."
        )
    },
    {
        "instruction": "Which herbal supplements might ease chronic constipation?",
        "response": (
            "Triphala powder is a popular choice in Ayurveda. Taken before bed with warm water, it often "
            "supports regular elimination."
        )
    },

    # 6) Diarrhea
    {
        "instruction": "What does Ayurveda say about managing mild diarrhea?",
        "response": (
            "Ayurveda suggests sipping rice water or pomegranate juice. Avoid heavy, oily foods until bowel "
            "movements normalize."
        )
    },
    {
        "instruction": "Which herbs help control diarrhea naturally?",
        "response": (
            "Bilva fruit is commonly used, as it may help firm stools. Fenugreek seeds can also have a "
            "soothing effect on the gut."
        )
    },

    # 7) Fever
    {
        "instruction": "How can I reduce a mild fever using Ayurvedic principles?",
        "response": (
            "Keep hydrated with room-temperature water or light herb teas. Ayurveda often recommends "
            "coriander tea for gentle cooling."
        )
    },
    {
        "instruction": "Which Ayurvedic remedies cool the body during a fever?",
        "response": (
            "Mint leaves, coriander seeds, and sandalwood paste are considered cooling. They help reduce "
            "excess heat (pitta) in the body."
        )
    },

    # 8) Headache
    {
        "instruction": "What is a simple Ayurvedic remedy for a mild headache?",
        "response": (
            "Apply a few drops of cooled, medicated oil like Brahmi or coconut oil on the scalp. Gentle "
            "temple massage can relieve tension."
        )
    },
    {
        "instruction": "Which spices or herbs soothe headaches in Ayurveda?",
        "response": (
            "Peppermint, ginger, and a pinch of cinnamon often help alleviate pain. Drinking warm water "
            "with a slice of ginger may ease discomfort."
        )
    },

    # 9) Allergies
    {
        "instruction": "How can Ayurveda help manage mild seasonal allergies?",
        "response": (
            "Regular nasal rinses (neti), a diet that avoids excessive dairy, and spices like turmeric "
            "support respiratory health."
        )
    },
    {
        "instruction": "Which herbal aids are traditionally used to ease allergy symptoms?",
        "response": (
            "Guduchi (Tinospora cordifolia) and tulsi are often recommended to bolster immunity. They "
            "help the body cope with allergens."
        )
    },

    # 10) Back Pain
    {
        "instruction": "What is a quick Ayurvedic tip for relieving simple lower back pain?",
        "response": (
            "Applying warm sesame oil with gentle massage can relax muscles. Light stretching or yoga "
            "postures support relief."
        )

    },
    {
        "instruction": "Which Ayurvedic practices can prevent recurring back pain?",
        "response": (
            "Regular exercise, maintaining good posture, and daily oil massage (abhyanga) help keep muscles "
            "strong and flexible."
        )
    }
]

df = pd.DataFrame(data)
df.to_csv("medical_qa.csv", index=False)
