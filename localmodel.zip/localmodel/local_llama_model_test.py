import openai

openai.api_base = "http://127.0.0.1:1234/v1"
# You can disable SSL verification for local testing if needed
openai.verify_ssl_certs = False
openai.api_key = "xyz"
response = openai.Completion.create(
    model="llama-3.2-3b-instruct",
    prompt="Hello, world!",
    max_tokens=150
)
print(response)
