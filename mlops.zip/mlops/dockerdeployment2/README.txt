docker build -t loanapproval-api .
docker run -p 8000:8000 loanapproval-api
curl -X POST "http://127.0.0.1:8000/predict" -H "Content-Type: application/json" -d '{"features": [1, 2]}'



