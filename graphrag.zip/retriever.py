import re
from neo4j import GraphDatabase

def extract_drug_from_query(query):
    """
    A simple extraction function that captures the first word in the query as the drug name.
    For more robust extraction, consider using an NLP library.
    """
    match = re.match(r'(\w+)', query)
    if match:
        return match.group(1)
    return None

def retrieve_diseases_for_drug(driver, drug_name):
    """
    Given a drug name, run a Cypher query to fetch all diseases that are connected to the drug node
    using the TREATED_FOR relationship.
    """
    cypher_query = (
        "MATCH (d:Drug {name: $drug})-[:TREATED_FOR]->(di:Disease) "
        "RETURN di.name AS disease"
    )
    with driver.session() as session:
        result = session.run(cypher_query, drug=drug_name)
        return [record["disease"] for record in result]

def main():
    # Neo4j connection details (update these as needed)
    neo4j_uri = ""
    neo4j_user = "neo4j"
    neo4j_password = ""
     # Replace with your Neo4j password
    
    # Connect to the Neo4j database.
    driver = GraphDatabase.driver(neo4j_uri, auth=(neo4j_user, neo4j_password))
    
    # Prompt the user with a natural language query.
    user_query = input("Enter your query (e.g., 'amoxicillin is used for treating which diseases?'): ").strip()
    
    # Extract the drug name from the query.
    drug_name = extract_drug_from_query(user_query)
    if not drug_name:
        print("Could not extract a drug name from the query.")
        driver.close()
        return
    
    # Retrieve associated diseases from the graph.
    diseases = retrieve_diseases_for_drug(driver, drug_name)
    
    if diseases:
        print(f"Diseases for which '{drug_name}' is used: {', '.join(diseases)}")
    else:
        print(f"No diseases found for '{drug_name}'.")
    
    driver.close()

if __name__ == '__main__':
    main()
