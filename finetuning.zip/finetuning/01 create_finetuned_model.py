# Import necessary libraries for model training and data manipulation
import os
import torch
import pandas as pd
from datasets import Dataset
from transformers import GPT2LMHeadModel, GPT2TokenizerFast, Trainer, TrainingArguments, DataCollatorForLanguageModeling


# -------------------------------
# 1. Load and Prepare the Dataset
# -------------------------------
# Assume your CSV has columns: "prompt" and "response"
df = pd.read_csv("medical_qa.csv")

# Combine the prompt and response into a single text field.
def combine_prompt_response(row):
    # You can customize this format as needed.
    return f"Prompt: {row['instruction']}\nResponse: {row['response']}\n"

df["text"] = df.apply(combine_prompt_response, axis=1)

# Convert the DataFrame to a Hugging Face Dataset.
dataset = Dataset.from_pandas(df[["text"]])

# -------------------------------
# 2. Tokenize the Dataset
# -------------------------------
# Import the GPT2TokenizerFast class
from transformers import GPT2TokenizerFast

model_name = "gpt2"  # using GPT-2 as an example model
tokenizer = GPT2TokenizerFast.from_pretrained(model_name)

# GPT-2 does not have a padding token by default; add one.
tokenizer.pad_token = tokenizer.eos_token

# Tokenization function: truncate/pad each sample.
def tokenize_function(examples):
    return tokenizer(examples["text"], truncation=True, max_length=512, padding="max_length")

tokenized_dataset = dataset.map(tokenize_function, batched=True, remove_columns=["text"])

# Split the dataset into training and evaluation sets.
split_dataset = tokenized_dataset.train_test_split(test_size=0.1)
train_dataset = split_dataset["train"]
eval_dataset = split_dataset["test"]

# -------------------------------
# 3. Establish baseline
# -------------------------------
print("Respinse BEFORE fine-tuning:")
prompt_text = "What is a quick Ayurvedic fix for a mild stomach ache?"
input_text = f"Prompt: {prompt_text}\nResponse:"
inputs = tokenizer(input_text, return_tensors="pt")

# Define the device
device = torch.device("cuda" if torch.cuda.is_available() else "cpu") # Define device here

# Move the inputs to the device
inputs = inputs.to(device) # Move inputs to the defined device

# Load the pre-trained GPT-2 model before calling eval() or generate()
from transformers import GPT2LMHeadModel # Import GPT2LMHeadModel here
model_name = "gpt2"  # Specify the model name
model = GPT2LMHeadModel.from_pretrained(model_name).to(device) # Load and move the model to the device

# Generate a response using the pre-trained model.
model.eval()
with torch.no_grad():
    output_sequences = model.generate(
        input_ids=inputs["input_ids"],
        max_length=150,      # adjust maximum generation length as needed
        temperature=0.7,     # control randomness
        top_p=0.9,           # nucleus sampling
        do_sample=True,
        num_return_sequences=1,
    )

generated_text = tokenizer.decode(output_sequences[0], skip_special_tokens=True)
print("Generated Response (Before Fine-Tuning):")
print(generated_text)
print("-" * 80)

# -------------------------------
# 4. Fine-Tune the Model
# -------------------------------
# Import necessary modules
from transformers import GPT2LMHeadModel, TrainingArguments, DataCollatorForLanguageModeling # importing GPT2LMHeadModel

# Load pre-trained GPT-2 model.
model = GPT2LMHeadModel.from_pretrained(model_name)
# Set the model's pad token id to match the tokenizer.
model.config.pad_token_id = tokenizer.eos_token_id

# Create a data collator for language modeling.
data_collator = DataCollatorForLanguageModeling(tokenizer=tokenizer, mlm=False)

# Set training arguments.
training_args = TrainingArguments(
    output_dir="./gpt2-ayurveda-finetuned",
    overwrite_output_dir=True,
    num_train_epochs=3,                     # adjust as needed
    per_device_train_batch_size=2,          # adjust based on your GPU/CPU
    per_device_eval_batch_size=2,
    evaluation_strategy="epoch",
    learning_rate=5e-5,
    weight_decay=0.01,
    logging_steps=10,
    save_steps=500,
    fp16=torch.cuda.is_available(),         # enables FP16 training if supported
)

# Initialize the Trainer.
trainer = Trainer(
    model=model,
    args=training_args,
    train_dataset=train_dataset,
    eval_dataset=eval_dataset,
    data_collator=data_collator,
)

# Fine-tune the model.
trainer.train()

# Save the fine-tuned model and tokenizer.
trainer.save_model("./fine_tuned_model")
tokenizer.save_pretrained("./fine_tuned_model")