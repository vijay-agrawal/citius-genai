import requests

def get_generated_text(prompt):
    url = "http://localhost:5001/v1/completion"  # Ensure this matches your Flask server's address and port
    headers = {"Content-Type": "application/json"}
    payload = {"prompt": prompt}
    
    response = requests.post(url, json=payload, headers=headers)
    
    if response.status_code == 200:
        # Print the generated text from the JSON response
        data = response.json()
        return data.get("generated_text", "No text returned")
    else:
        # If you get a 403 or another error, print the status code and error message
        return f"Error {response.status_code}: {response.text}"

if __name__ == "__main__":
    prompt = "How can ayurveda be used to cure stomach ache?"
    answer = get_generated_text(prompt)
    print("Answer:", answer)