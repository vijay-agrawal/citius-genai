#pip install fastapi uvicorn

from fastapi import FastAPI
import joblib
import numpy as np
from pydantic import BaseModel

# Load the trained model
model = joblib.load("random_forest_model.joblib")

# Define request structure
class InputData(BaseModel):
    features: list

# Initialize FastAPI app
app = FastAPI()

@app.post("/predict")
def predict(data: InputData):
    features = np.array(data.features).reshape(1, -1)
    prediction = model.predict(features).tolist()
    return {"prediction": prediction}

# Run the app using: uvicorn script_name:app --reload
# Test the API
# curl -X 'POST' 'http://127.0.0.1:8000/predict' -H 'Content-Type: application/json' -d '{"features": [1, 2]}'



