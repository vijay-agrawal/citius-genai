from flask import Flask, request, jsonify
import torch
from transformers import GPT2LMHeadModel, GPT2TokenizerFast

app = Flask(__name__)

# Load your fine-tuned model and tokenizer
model_name = "./fine_tuned_model"  # adjust if your model is saved elsewhere
tokenizer = GPT2TokenizerFast.from_pretrained(model_name)
model = GPT2LMHeadModel.from_pretrained(model_name)
# Ensure the pad token is set to the EOS token
model.config.pad_token_id = tokenizer.eos_token_id

# Move model to GPU if available
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
model.to(device)
model.eval()

@app.route('/v1/completion', methods=['POST'])
def generate():
    # Expect JSON with a "prompt" key
    data = request.json
    print(data)
    prompt_text = data.get("prompt", "")
    print(prompt_text)
    if not prompt_text:
        return jsonify({"error": "No prompt provided"}), 400

    # Create the input text following your format
    input_text = f"Prompt: {prompt_text}\nResponse:"
    inputs = tokenizer(input_text, return_tensors="pt", truncation=True, max_length=512, padding="max_length").to(device)
    
    # Tokenize the prompt.
    inputs = tokenizer(input_text, return_tensors="pt").to(model.device)
    
    # Generate a response
    output_sequences = model.generate(
        input_ids=inputs["input_ids"],
        max_length=150,
        temperature=0.7,
        top_p=0.9,
        do_sample=True,
        num_return_sequences=1,
        pad_token_id=tokenizer.eos_token_id  # ensures proper padding behavior
    )
    
    generated_text = tokenizer.decode(output_sequences[0], skip_special_tokens=True)
    return jsonify({"generated_text": generated_text})

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5001)