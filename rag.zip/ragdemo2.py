import os
import numpy as np
from typing import List, Dict
from sentence_transformers import SentenceTransformer
from sklearn.metrics.pairwise import cosine_similarity
from anthropic import Anthropic

class DocumentStore:
    def __init__(self, documents: List[str]):
        """
        Initialize document store with embedding capabilities
        
        :param documents: List of text documents to store and retrieve
        """
        self.documents = documents
        self.model = SentenceTransformer('all-MiniLM-L6-v2')
        self.embeddings = self._create_embeddings()
    
    def _create_embeddings(self) -> np.ndarray:
        """Create embeddings for all documents."""
        return self.model.encode(self.documents)
    
    def retrieve(self, query: str, top_k: int = 3) -> List[Dict]:
        """
        Retrieve most relevant documents for the query
        
        :param query: Search query string
        :param top_k: Number of top documents to retrieve
        :return: List of retrieved documents with similarity scores
        """
        # Create query embedding
        query_embedding = self.model.encode([query])[0]
        
        # Calculate similarities
        similarities = cosine_similarity([query_embedding], self.embeddings)[0]
        
        # Get top-k documents
        top_indices = np.argsort(similarities)[-top_k:][::-1]
        
        results = []
        for idx in top_indices:
            results.append({
                'document': self.documents[idx],
                'similarity': similarities[idx]
            })
        
        return results

class AdvancedRAGApplication:
    def __init__(self, documents: List[str], api_key: str = None):
        """
        Initialize RAG application with document store and LLM
        
        :param documents: List of documents to use as context
        :param api_key: Anthropic API key (optional, can use environment variable)
        """
        self.doc_store = DocumentStore(documents)
        
        # Initialize Anthropic client
        self.client = Anthropic(api_key=api_key or os.getenv('ANTHROPIC_API_KEY'))
    
    def generate_response(self, query: str, use_retrieval: bool = True) -> str:
        """
        Generate a comprehensive response using retrieved documents and LLM
        
        :param query: User's query
        :param use_retrieval: Whether to use document retrieval
        :return: Generated response
        """
        # Retrieve relevant documents if retrieval is enabled
        retrieved_docs = self.doc_store.retrieve(query) if use_retrieval else []
        
        # Construct prompt
        prompt = self._construct_prompt(query, retrieved_docs)
        
        # Generate response using Claude
        try:
            response = self.client.messages.create(
                model="claude-3-opus-20240229",
                max_tokens=1000,
                messages=[
                    {
                        "role": "user",
                        "content": prompt
                    }
                ]
            )
            return response.content[0].text
        except Exception as e:
            return f"Error generating response: {str(e)}"
    
    def _construct_prompt(self, query: str, retrieved_docs: List[Dict]) -> str:
        """
        Construct a prompt that combines query, retrieved documents, and context
        
        :param query: User's original query
        :param retrieved_docs: List of retrieved documents
        :return: Constructed prompt string
        """
        # Start with context instructions
        prompt = """You are an advanced AI assistant capable of:
1. Using retrieved context when relevant
2. Drawing from your broad knowledge base
3. Providing clear, helpful, and accurate responses

"""
        
        # Add retrieved documents if available
        if retrieved_docs:
            prompt += "Relevant context documents:\n"
            for i, doc in enumerate(retrieved_docs, 1):
                prompt += f"{i}. {doc['document']} (Relevance: {doc['similarity']:.2f})\n"
            prompt += "\n"
        
        # Add the query with instructions
        prompt += f"""Please answer the following query. 
- If the retrieved documents are relevant, incorporate their information.
- If the documents are not directly relevant, use your general knowledge.
- Provide a comprehensive and nuanced response.

Query: {query}

Response:"""
        
        return prompt

def main():
    # Sample documents (your custom knowledge base)
    documents = [
        "Python was created by Guido van Rossum in the late 1980s.",
        "Python supports multiple programming paradigms including object-oriented, functional, and procedural programming.",
        "Machine learning is a subset of artificial intelligence that focuses on algorithms that can learn from and make predictions based on data.",
        "Neural networks are a key technology in deep learning, inspired by the structure of the human brain.",
        "Anthropic is an AI research company focused on developing safe and ethical AI systems."
    ]
    
    # Initialize RAG application (assumes ANTHROPIC_API_KEY is set in environment)
    rag = AdvancedRAGApplication(documents)
    
    # Example queries demonstrating different scenarios
    queries = [
        "Tell me about Python's history",  # Retrieval-based
        "Explain machine learning",  # Combination of retrieval and knowledge
        "What is quantum computing?"  # Purely knowledge-based
    ]
    
    # Generate responses
    for query in queries:
        print(f"\nQuery: {query}")
        print("=" * 50)
        response = rag.generate_response(query)
        print(response)
        print("\n")

if __name__ == "__main__":
    main()

# Setup instructions:
# 1. Install dependencies:
#    pip install sentence-transformers numpy scikit-learn anthropic
# 2. Set your Anthropic API key:
#    export ANTHROPIC_API_KEY='your-api-key-here'
# 3. Run the script