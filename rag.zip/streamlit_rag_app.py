# Import os to handle environment variables
#
# To run this app
# 
# streamlit run <path to this file>
#
import os
from dotenv import load_dotenv
import streamlit as st
from langchain_openai import AzureChatOpenAI
from langchain_openai import AzureOpenAIEmbeddings
from langchain_core.messages import HumanMessage
from langchain_community.callbacks import get_openai_callback
from langchain.chains import RetrievalQA

load_dotenv()

azure_config = {
    "AZURE_OPENAI_ENDPOINT": os.getenv("AZURE_OPENAI_ENDPOINT"),
    "AZURE_OPENAI_MODEL_DEPLOYMENT_NAME": os.getenv("AZURE_OPENAI_MODEL_DEPLOYMENT_NAME"),
    "AZURE_OPENAI_MODEL_NAME": os.getenv("AZURE_OPENAI_MODEL_NAME"),
    "AZURE_OPENAI_API_KEY": os.getenv("AZURE_OPENAI_API_KEY"),
    "AZURE_OPENAI_API_VERSION": os.getenv("AZURE_OPENAI_API_VERSION")
    }

st.subheader("GenAI production pipeline - Evaluation, monitoring, logging and guardrails")


CHROMA_PATH = os.path.join(os.getcwd(), "chroma_db")

def load_embeddings_chroma(persist_directory=CHROMA_PATH):
    from langchain.vectorstores import Chroma

    # Instantiate the same embedding model used during creation
    embeddings = AzureOpenAIEmbeddings(
        model="",
        api_key="",
        api_version="2024-02-01",
        azure_endpoint=""
    )

    # Load the Chroma vector store from the specified directory, using the provided embedding function
    vector_store = Chroma(persist_directory=persist_directory, embedding_function=embeddings) 

    return vector_store  # Return the loaded vector store    

def generate_response(input_text):

    vector_store = load_embeddings_chroma()
    retriever = vector_store.as_retriever(search_type='similarity', search_kwargs={'k': 5})

    llm = AzureChatOpenAI(temperature=0,
                      api_key=azure_config["AZURE_OPENAI_API_KEY"],
                      openai_api_version=azure_config["AZURE_OPENAI_API_VERSION"],
                      azure_endpoint=azure_config["AZURE_OPENAI_ENDPOINT"],
                      model=azure_config["AZURE_OPENAI_MODEL_DEPLOYMENT_NAME"],
                      validate_base_url=False)

 
    chain = RetrievalQA.from_chain_type(llm=llm, chain_type="stuff", retriever=retriever)
    
    response = chain.invoke(input_text)
    st.info(response)
#   message = HumanMessage(
#        content=input_text
#    )
    
#    with get_openai_callback() as cb:
#        st.info(llm([message]).content) # chat model output
#        st.info(cb) # callback output (like cost)

    ### TODO:
    ### Add your evaluation, monitoring, logging, guardrails code here
    ###


user_question = st.text_input("Ask any question about Pankaj CV. Press enter to submit", key="user_question")
if user_question:
    generate_response(user_question)
