import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score, classification_report
import pickle

# Sample data preparation (replace this with your actual data)
data = {
    'age': np.random.randint(18, 70, 1000),
    'credit_score': np.random.randint(300, 850, 1000),
    'income': np.random.randint(30000, 120000, 1000),
    'loan_amount': np.random.randint(5000, 50000, 1000),
    'loan_approved': np.random.choice([0, 1], 1000)
}
df = pd.DataFrame(data)

# Separate features and target
X = df[['age', 'credit_score', 'income', 'loan_amount']]
y = df['loan_approved']

# Split the data
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# Create and train the model
rf_model = RandomForestClassifier(n_estimators=100, random_state=42)
rf_model.fit(X_train, y_train)

# Evaluate the model
y_pred = rf_model.predict(X_test)
print("Model Accuracy:", accuracy_score(y_test, y_pred))
print("\nClassification Report:")
print(classification_report(y_test, y_pred))

# Save the model to a file
model_filename = 'loan_approval_model.pkl'
with open(model_filename, 'wb') as file:
    pickle.dump(rf_model, file)
print(f"\nModel saved to {model_filename}")

# Example of loading and using the saved model
def load_and_predict(model_path, input_data):
    """
    Load the saved model and make predictions on new data
    
    Parameters:
    model_path (str): Path to the saved pickle file
    input_data (dict): Dictionary containing feature values
    
    Returns:
    prediction: Model prediction (0 or 1)
    probability: Prediction probability
    """
    # Load the model
    with open(model_path, 'rb') as file:
        loaded_model = pickle.load(file)
    
    # Convert input data to DataFrame
    input_df = pd.DataFrame([input_data])
    
    # Make prediction
    prediction = loaded_model.predict(input_df)[0]
    probability = loaded_model.predict_proba(input_df)[0]
    
    return prediction, probability

# Example usage of the loaded model
sample_input = {
    'age': 35,
    'credit_score': 720,
    'income': 60000,
    'loan_amount': 25000
}

prediction, probability = load_and_predict(model_filename, sample_input)
print("\nExample Prediction:")
print(f"Loan Approval Prediction: {'Approved' if prediction == 1 else 'Not Approved'}")
print(f"Probability: {probability[1]:.2f}")