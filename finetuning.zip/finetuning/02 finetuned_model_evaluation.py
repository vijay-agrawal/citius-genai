# -------------------------------
# 5. Inference Example
# -------------------------------
# Load the fine-tuned model and tokenizer (if needed).
from transformers import GPT2LMHeadModel, GPT2TokenizerFast, Trainer, TrainingArguments, DataCollatorForLanguageModeling
model = GPT2LMHeadModel.from_pretrained("./fine_tuned_model")
tokenizer = GPT2TokenizerFast.from_pretrained("./fine_tuned_model")

# Set model to evaluation mode.
model.eval()

# Example prompt: "what are remedies for cough"
prompt_text = "What is a quick Ayurvedic fix for a mild stomach ache?"
input_text = f"Prompt: {prompt_text}\nResponse:"

# Tokenize the prompt.
inputs = tokenizer(input_text, return_tensors="pt").to(model.device)

# Generate a response.
output_sequences = model.generate(
    input_ids=inputs["input_ids"],
    max_length=150,      # adjust max generation length as needed
    temperature=0.7,     # control randomness
    top_p=0.9,           # nucleus sampling
    do_sample=True,
    num_return_sequences=1,
)

# Decode and print the generated text.
generated_text = tokenizer.decode(output_sequences[0], skip_special_tokens=True)
print("Generated Response:")
print(generated_text)

# -------------------------------
# 5. Inference Example with a non existent disease
# -------------------------------
# Load the fine-tuned model and tokenizer (if needed).
# model = GPT2LMHeadModel.from_pretrained("./gpt2-ayurveda-finetuned")
# tokenizer = GPT2TokenizerFast.from_pretrained("./gpt2-ayurveda-finetuned")

# Set model to evaluation mode.
model.eval()

# Example prompt: "what are remedies for cough"
prompt_text = "What is a quick Ayurvedic fix for tomphatantrum?"
input_text = f"Prompt: {prompt_text}\nResponse:"

# Tokenize the prompt.
inputs = tokenizer(input_text, return_tensors="pt").to(model.device)

# Generate a response.
output_sequences = model.generate(
    input_ids=inputs["input_ids"],
    max_length=150,      # adjust max generation length as needed
    temperature=0.7,     # control randomness
    top_p=0.9,           # nucleus sampling
    do_sample=True,
    num_return_sequences=1,
)

# Decode and print the generated text.
generated_text = tokenizer.decode(output_sequences[0], skip_special_tokens=True)
print("Generated Response:")
print(generated_text)