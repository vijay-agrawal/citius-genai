STEP 1:
Organize your files in a directory like this:

your-project-directory/
├── app.py                    # Your Flask application
├── loan_approval_model.pkl   # Your saved model
├── requirements.txt          # Dependencies
└── Dockerfile               # Docker configuration

See the requirements.txt in this folder as an example

STEP 2: Build the docker image
docker build -t loan-prediction-api .


STEP 3: Run the docker container
docker run -d -p 5000:5000 --name loan-api loan-prediction-api

STEP 4: Test it:
curl -X POST http://localhost:5000/predict \
     -H "Content-Type: application/json" \
     -d '{"age": 35, "credit_score": 720, "income": 60000, "loan_amount": 25000}'

ADDITIONAL OPTIONAL STEPS
View Logs:
docker logs loan-api

Enter docker shell:
docker exec -it loan-api /bin/bash

Stop the docker container:
docker stop loan-api

Remove the docker container
docker rm loan-api


