from flask import Flask, request, jsonify
import joblib
import numpy as np

# Load the trained model
model = joblib.load("random_forest_model.joblib")

# Initialize Flask app
app = Flask(__name__)

@app.route('/predict', methods=['POST'])
def predict():
    try:
        data = request.get_json()  # Expect JSON input
        features = np.array(data['features']).reshape(1, -1)  # Reshape for model
        prediction = model.predict(features).tolist()
        return jsonify({"prediction": prediction})
    except Exception as e:
        return jsonify({"error": str(e)})

# Run the app
if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000)

## Test using curl or postman
#curl -X POST "http://127.0.0.1:5000/predict" -H "Content-Type: application/json" -d '{"features": [1, 2]}'


